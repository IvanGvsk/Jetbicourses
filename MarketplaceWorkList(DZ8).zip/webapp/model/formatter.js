sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function(DateFormat) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		modifiedInfo: function(oDate, sFullName) {
			if (!oDate || !sFullName) {
				return "";
			} else {
				var oDateFormat = DateFormat.getDateTimeInstance({
					pattern: "EEE, MMM dd, yyyy"
				});
				
				var nTimeAgo = new Date().getTime() - oDate.getTime();
				var Days = parseInt(nTimeAgo / (1000 * 60 * 60 * 24)) + " " + this.getResourceBundle().getText("tDays");
				var Hours = parseInt((nTimeAgo % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)) + " " + this.getResourceBundle().getText("tHours");
				var Minutes = parseInt((nTimeAgo % (1000 * 60 * 60)) / (1000 * 60)) + " " + this.getResourceBundle().getText("tMinutes");
				var sDateAgo = " " + Days + " " + Hours + " " + Minutes;
				return sFullName.split(" ")[1] + " " + oDateFormat.format(oDate) + sDateAgo;
			}

		}

	};

});